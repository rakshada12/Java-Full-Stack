package com.yash.oms.model;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "items")
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long itemId;
    @NotBlank(message="Item cannot be blank")
    private String itemName;
    @NotNull(message="Id cannot be null")
    private Long restaurantId;
    @NotNull(message="quantity cannot be null")
    private Integer quantityOfItem;
    private Double cost;
//    @ManyToOne
//    @JoinColumn(name = "restaurant_id_fk")
//    private Restaurant restaurant;
	
	public Item(String itemName, Long restaurantId, Integer quantityOfItem, Double cost) {
		super();
	
		this.itemName = itemName;
		this.restaurantId = restaurantId;
		this.quantityOfItem = quantityOfItem;
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", itemName=" + itemName + ", restaurantId=" + restaurantId
				+ ", quantityOfItem=" + quantityOfItem + ", cost=" + cost + "]";
	}
	
   
}

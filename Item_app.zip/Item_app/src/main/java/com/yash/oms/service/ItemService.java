package com.yash.oms.service;

import java.util.List;

import com.yash.oms.model.Item;
//import com.yash.oms.model.Restaurant;


public interface ItemService {
	public Item addItem(Item item);
	public Item updateItem(Long restaurantId, Item item);
	public Item viewItem(Long itemId);
	public void removeItem(Long itemId);
	public List<Item> viewAllItemsByRestaurant(Long restaurantId);
	public List<Item> viewAllItems();

}

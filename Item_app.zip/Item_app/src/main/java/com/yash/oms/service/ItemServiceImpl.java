package com.yash.oms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.oms.exception.ItemNotFoundException;
import com.yash.oms.exception.RestaurantNotFoundException;
import com.yash.oms.model.Item;
import com.yash.oms.model.Restaurant;
//import com.yash.oms.model.Restaurant;
import com.yash.oms.repository.ItemRepository;

@Service
public class ItemServiceImpl implements ItemService {
    
    @Autowired
    private ItemRepository itemRepository;

   
    public Item addItem(Item item) {
        return itemRepository.save(item);
    }

    
    public Item updateItem(Long restaurantId, Item item) { 
    	Item currentItem = itemRepository.findById(item.getItemId())
                .orElseThrow(() -> new ItemNotFoundException("Item not found"));
    	if (!currentItem.getRestaurantId().equals(restaurantId)) {
            throw new RestaurantNotFoundException("Item does not belong to the specified restaurant");
        }
        return itemRepository.save(item);
    }

    
    public Item viewItem(Long itemId) {
        return itemRepository.findById(itemId)
                .orElseThrow(() -> new ItemNotFoundException("Item not found"));
    }

    
    public void removeItem(Long itemId) {
        if (!itemRepository.existsById(itemId)) {
            throw new ItemNotFoundException("Item not found");
        }
        itemRepository.deleteById(itemId);
    }

   
    public List<Item> viewAllItemsByRestaurant(Long restaurantId) {
    	Restaurant restaurant = new Restaurant();
        restaurant.setRestaurantId(restaurantId);
        return itemRepository.findByRestaurantId(restaurantId);
    }

   
    public List<Item> viewAllItems() {
        return itemRepository.findAll();
    }
}

package com.yash.oms.Item_app.ServiceTest;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;

import com.yash.oms.exception.ItemNotFoundException;
import com.yash.oms.model.Item;
import com.yash.oms.repository.ItemRepository;
import com.yash.oms.service.ItemServiceImpl;

@ExtendWith(MockitoExtension.class)
public class ItemServiceTest {
	@InjectMocks
    private ItemServiceImpl itemService;

    @Mock
    private ItemRepository itemRepository;
    private Long itemId;
    private Item itemnew;
    
    @BeforeEach
    public void createTestItem() {
        itemnew = new Item("abc", 2L, 1, 10.0);
        itemnew.setItemId(1L);
        itemService.addItem(itemnew);
        itemId = itemnew.getItemId();
        Item item3 = new Item();
        item3.setItemId(10L);
    }

    @Test
    public void testAddItem_ShouldReturnTrue() {
        Item item = new Item("abc", 1L, 1, 10.0);
        when(itemRepository.save(item)).thenReturn(item);
        Item savedItem = itemService.addItem(item);
        assertNotNull(savedItem);
        assertEquals(item, savedItem);
   
    }
    
    
    @Test
    public void testUpdateItem_ShouldReturnTrue() {
        Long restaurantId = 1L;
        Item currentItem = new Item();
        currentItem.setItemId(1L);
        currentItem.setRestaurantId(restaurantId);

        Item item2 = new Item();
        item2.setItemId(1L);

        when(itemRepository.findById(item2.getItemId())).thenReturn(Optional.of(currentItem));
        when(itemRepository.save(item2)).thenReturn(item2);

        Item updatedItem = itemService.updateItem(restaurantId, item2);
        assertNotNull(updatedItem);
        assertEquals(item2.getItemId(), updatedItem.getItemId());
      
    }
    
    @Test
    public void testUpdateItem_ItemNotFound() {
        when(itemRepository.findById(1L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(ItemNotFoundException.class, () -> {
            itemService.updateItem(1L, itemnew);
        });

        assertEquals("Item not found", exception.getMessage());
    }

    @Test
    public void testViewItem_ItemFound() {
        when(itemRepository.findById(1L)).thenReturn(Optional.of(itemnew));

        Item foundItem = itemService.viewItem(1L);
        assertNotNull(foundItem);
        assertEquals(1L, foundItem.getItemId());
    }
    
    @Test
    public void testViewAllItemsByRestaurant() {
        when(itemRepository.findByRestaurantId(1L)).thenReturn(List.of(itemnew));

        List<Item> items = itemService.viewAllItemsByRestaurant(1L);
        assertEquals(1, items.size());
        assertEquals("abc", items.get(0).getItemName());
      
    }
    
    @Test
    public void testViewAllItems() {
    	Item item1 = new Item("Item1", 1L, 10, 100.0);
       Item item2 = new Item("Item2", 1L, 5, 500.0);
        List<Item> items = Arrays.asList(item1, item2);
        when(itemRepository.findAll()).thenReturn(items);

        List<Item> result = itemService.viewAllItems();
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Item1", result.get(0).getItemName());
        assertEquals("Item2", result.get(1).getItemName());
    }
}


